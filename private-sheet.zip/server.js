const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'sheet-data.json');
const CONFIG_FILE = path.join(__dirname, 'config.json');

// Default password: change this via the app or set env var SHEET_PASSWORD
const DEFAULT_PASSWORD = process.env.SHEET_PASSWORD || 'changeme123';

app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- Helpers ---
function hashPassword(pw) {
  return crypto.createHash('sha256').update(pw + 'private-sheet-salt-2024').digest('hex');
}

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch (e) {}
  return { passwordHash: hashPassword(DEFAULT_PASSWORD) };
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {}
  return { cells: {}, fmt: {}, dims: { rows: 30, cols: 10 } };
}

function saveSheetData(d) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(d));
}

function makeToken() {
  return crypto.randomBytes(32).toString('hex');
}

let activeToken = null;
let tokenExpiry = 0;

// --- Auth routes ---
app.post('/api/login', (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Missing password' });
  const cfg = loadConfig();
  if (hashPassword(password) !== cfg.passwordHash) {
    return res.status(401).json({ error: 'Incorrect password' });
  }
  activeToken = makeToken();
  tokenExpiry = Date.now() + 8 * 60 * 60 * 1000; // 8 hours
  res.json({ token: activeToken });
});

function authMiddleware(req, res, next) {
  const auth = req.headers['authorization'] || '';
  const token = auth.replace('Bearer ', '').trim();
  if (!token || token !== activeToken || Date.now() > tokenExpiry) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  // Refresh expiry on activity
  tokenExpiry = Date.now() + 8 * 60 * 60 * 1000;
  next();
}

app.post('/api/change-password', authMiddleware, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: 'Password too short' });
  const cfg = loadConfig();
  cfg.passwordHash = hashPassword(newPassword);
  saveConfig(cfg);
  // Invalidate current session
  activeToken = makeToken();
  tokenExpiry = Date.now() + 8 * 60 * 60 * 1000;
  res.json({ token: activeToken, message: 'Password changed' });
});

// --- Data routes ---
app.get('/api/data', authMiddleware, (req, res) => {
  res.json(loadData());
});

app.post('/api/data', authMiddleware, (req, res) => {
  const d = req.body;
  if (!d || typeof d !== 'object') return res.status(400).json({ error: 'Invalid data' });
  saveSheetData(d);
  res.json({ ok: true });
});

app.post('/api/logout', authMiddleware, (req, res) => {
  activeToken = null;
  tokenExpiry = 0;
  res.json({ ok: true });
});

// --- Init config if not exists ---
if (!fs.existsSync(CONFIG_FILE)) {
  saveConfig({ passwordHash: hashPassword(DEFAULT_PASSWORD) });
  console.log(`\n✅ Config initialized. Default password: "${DEFAULT_PASSWORD}"`);
  console.log('   Change it in the app after first login.\n');
}

app.listen(PORT, () => {
  console.log(`🔒 Private Sheet running at http://localhost:${PORT}`);
});
