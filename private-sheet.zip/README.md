# 🔒 Private Sheet

A personal password-protected spreadsheet accessible from anywhere via a web browser.

---

## Quick Start (Local)

```bash
npm install
npm start
# Open http://localhost:3000
# Default password: changeme123
```

Change your password in the app: **Settings → Change Password**

---

## Deploy for Free (Accessible Anywhere)

### Option A: Railway (Recommended — easiest)

1. Create a free account at https://railway.app
2. Click **New Project → Deploy from GitHub**
3. Push this folder to a GitHub repo first:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   # Create a repo on GitHub, then:
   git remote add origin https://github.com/YOUR_USERNAME/private-sheet.git
   git push -u origin main
   ```
4. In Railway, select your repo → it auto-detects Node.js and deploys
5. Set environment variable: `SHEET_PASSWORD=YourSecretPassword`
6. Railway gives you a public URL like `https://private-sheet-xyz.railway.app`

### Option B: Render (Also free)

1. Create a free account at https://render.com
2. New → Web Service → Connect your GitHub repo
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Add Environment Variable: `SHEET_PASSWORD=YourSecretPassword`
6. Deploy — you get a URL like `https://private-sheet.onrender.com`

> ⚠️ Free Render instances sleep after 15 min inactivity. Upgrade to $7/mo for always-on.

### Option C: Fly.io (Free tier, always on)

```bash
npm install -g flyctl
flyctl auth login
flyctl launch        # follow prompts
flyctl secrets set SHEET_PASSWORD=YourSecretPassword
flyctl deploy
```

### Option D: VPS (DigitalOcean, Hetzner, etc.)

```bash
# On your VPS:
git clone https://github.com/YOUR_USERNAME/private-sheet.git
cd private-sheet
npm install
SHEET_PASSWORD=YourSecretPassword npm start

# Use PM2 to keep it running:
npm install -g pm2
SHEET_PASSWORD=YourSecretPassword pm2 start server.js --name private-sheet
pm2 save
```

Add nginx reverse proxy for HTTPS (recommended for production).

---

## Features

- 🔐 Password-protected — only you can access
- 💾 Data saved on server — available from any device/browser
- 📊 Spreadsheet with formulas: `=SUM`, `=AVERAGE`, `=COUNT`, `=MAX`, `=MIN`
- 🎨 Bold, italic, alignment, text color, background color
- ➕ Add/remove rows and columns
- 📥 Export to CSV
- 🔄 Auto-saves as you type
- 🔒 8-hour session — locks automatically

---

## Files

```
private-sheet/
├── server.js          # Node.js backend (Express)
├── package.json
├── config.json        # Auto-created: stores password hash (never stores plaintext)
├── sheet-data.json    # Auto-created: your spreadsheet data
└── public/
    └── index.html     # Full frontend app
```

---

## Security Notes

- Passwords are hashed with SHA-256 — never stored in plaintext
- Sessions expire after 8 hours of inactivity
- All data is stored locally on your server in `sheet-data.json`
- For production, use HTTPS (Railway/Render/Fly.io provide this automatically)
